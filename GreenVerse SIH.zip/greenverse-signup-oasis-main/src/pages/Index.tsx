import { useState } from "react";
import { Leaf, Sparkles } from "lucide-react";

const Index = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleDemoUser = () => {
    setUsername("demo_user");
    setPassword("••••••••");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate signup process
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Here you would typically make an API call
    console.log("Signup attempt:", { username, password });
    
    setIsLoading(false);
    alert("Welcome to Greenverse! 🌱");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="floating-leaf top-20 left-10 w-8 h-8 text-accent">
        <Leaf />
      </div>
      <div className="floating-leaf top-40 right-20 w-6 h-6 text-moss-green" style={{ animationDelay: "2s" }}>
        <Leaf />
      </div>
      <div className="floating-leaf bottom-32 left-20 w-10 h-10 text-leaf-green" style={{ animationDelay: "4s" }}>
        <Leaf />
      </div>
      
      {/* Pulsing Orbs */}
      <div className="pulsing-orb top-32 right-32 w-16 h-16 bg-accent"></div>
      <div className="pulsing-orb bottom-40 right-10 w-12 h-12 bg-leaf-green" style={{ animationDelay: "2s" }}></div>
      <div className="pulsing-orb top-60 left-32 w-20 h-20 bg-moss-green" style={{ animationDelay: "3s" }}></div>

      {/* Main Content */}
      <div className="w-full max-w-md relative z-10">
        {/* Logo/Title */}
        <div className="text-center mb-8">
          <h1 className="greenverse-title mb-4">
            Greenverse
          </h1>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <Sparkles className="w-5 h-5 text-accent" />
            <span className="text-lg font-medium">Play for Impact</span>
            <Sparkles className="w-5 h-5 text-accent" />
          </div>
        </div>

        {/* Signup Form */}
        <form onSubmit={handleSubmit} className="signup-form">
          <div className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-semibold text-foreground mb-2">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                className="nature-input"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-foreground mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="nature-input"
                required
                minLength={6}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="leaf-button group"
            >
              <span className="flex items-center justify-center gap-2">
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Creating your account...
                  </>
                ) : (
                  <>
                    <Leaf className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                    Sign Up
                  </>
                )}
              </span>
            </button>

            {/* Demo User Button */}
            <button
              type="button"
              onClick={handleDemoUser}
              className="w-full py-3 px-6 rounded-2xl border-2 border-earth-brown/30 bg-sage/20 text-earth-brown font-medium hover:bg-sage/40 hover:border-earth-brown/50 transition-all duration-300 hover:shadow-md"
            >
              Demo User
            </button>
          </div>
        </form>

        {/* Social Login Section */}
        <div className="mt-8">
          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border/30"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="bg-background px-4 text-muted-foreground font-medium">Or continue with</span>
            </div>
          </div>

          {/* Social Login Buttons */}
          <div className="mt-6 space-y-3">
            {/* Google Button */}
            <button
              type="button"
              onClick={() => console.log("Google login clicked")}
              className="w-full flex items-center justify-center gap-3 px-6 py-3 rounded-2xl border-2 border-border/50 bg-card/60 backdrop-blur-sm text-foreground font-medium hover:bg-sage/30 hover:border-sage transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              Continue with Google
            </button>

            {/* Microsoft Button */}
            <button
              type="button"
              onClick={() => console.log("Microsoft login clicked")}
              className="w-full flex items-center justify-center gap-3 px-6 py-3 rounded-2xl border-2 border-border/50 bg-card/60 backdrop-blur-sm text-foreground font-medium hover:bg-sage/30 hover:border-sage transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M11.4 24H0V12.6h11.4V24zM24 24H12.6V12.6H24V24zM11.4 11.4H0V0h11.4v11.4zM24 11.4H12.6V0H24v11.4z"/>
              </svg>
              Continue with Microsoft
            </button>
          </div>
        </div>

        {/* Inspirational Message */}
        <div className="mt-8 text-center">
          <p className="text-muted-foreground leading-relaxed">
            🌱 <span className="font-medium text-foreground">Every small action creates ripples of change.</span>
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Join our community and discover how gaming can heal the planet, one sustainable choice at a time.
          </p>
        </div>

        {/* Additional Links */}
        <div className="mt-6 text-center text-sm text-muted-foreground">
          Already have an account?{" "}
          <a href="#" className="text-accent hover:text-leaf-green font-medium transition-colors">
            Sign in here
          </a>
        </div>
      </div>
    </div>
  );
};

export default Index;